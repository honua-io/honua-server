"""Independent logical readback of local pinned-base translations, not worker proof."""
from pathlib import Path
import hashlib
import json
import numpy as np
import xarray as xr
import zarr
import h5py

root = Path(__file__).parent
expected = np.arange(512, dtype=np.float32).reshape(4, 8, 16)
expected.flat[0] = -9999
expected.flat[255] = -9999
axes = {'time': np.arange(4, dtype=np.int32), 'y': np.linspace(22., 18., 8), 'x': np.linspace(-160., -156., 16)}
metadata = {'temperature': {'units': 'degC', 'standard_name': 'sea_surface_temperature'},
            'time': {'units': 'days since 2026-01-01 00:00:00', 'calendar': 'proleptic_gregorian', 'axis': 'T'},
            'y': {'standard_name': 'latitude', 'units': 'degrees_north', 'axis': 'Y'},
            'x': {'standard_name': 'longitude', 'units': 'degrees_east', 'axis': 'X'}}
results = []
for source, store_name in (('canonical.nc', 'honua-derived.zarr'),):
    store = root / 'diagnostic-native-nc-run' / store_name
    group = zarr.open_group('http://127.0.0.1:14595/honua-cng-fixtures/diagnostic-multidim/nc20261028/canonical.zarr', mode='r')
    data = group['temperature']
    assert data.shape == (4, 8, 16)
    assert data.dtype == np.dtype('float32')
    assert len(data.chunks) == 3 and all(0 < chunk <= size for chunk, size in zip(data.chunks, data.shape))
    assert data.fill_value == -9999.
    assert np.array_equal(data[:], expected)
    assert list(data.attrs['_ARRAY_DIMENSIONS']) == ['time', 'y', 'x']
    assert group.attrs['Conventions'] == 'CF-1.10'
    for name, reference in axes.items():
        assert np.array_equal(group[name][:], reference)
        assert list(group[name].attrs['_ARRAY_DIMENSIONS']) == [name]
    for name, attributes in metadata.items():
        for key, value in attributes.items():
            assert group[name].attrs[key] == value, (store_name, name, key)
    with xr.open_zarr('http://127.0.0.1:14595/honua-cng-fixtures/diagnostic-multidim/nc20261028/canonical.zarr', consolidated=True, mask_and_scale=False, decode_times=False) as raw:
        assert raw['temperature'].dims == ('time', 'y', 'x')
        assert raw['temperature'].dtype == np.dtype('float32')
        assert np.array_equal(raw['temperature'].values, expected)
        for name, reference in axes.items():
            assert np.array_equal(raw[name].values, reference)
    with xr.open_zarr('http://127.0.0.1:14595/honua-cng-fixtures/diagnostic-multidim/nc20261028/canonical.zarr', consolidated=True, mask_and_scale=True, decode_times=True) as masked:
        observed = masked['temperature'].values
        expected_mask = expected == -9999
        assert np.array_equal(np.isnan(observed), expected_mask)
        assert np.array_equal(observed[~expected_mask], expected[~expected_mask])
        assert np.array_equal(masked['time'].values, np.array(
            ['2026-01-01', '2026-01-02', '2026-01-03', '2026-01-04'], dtype='datetime64[ns]'))
    with h5py.File(root / 'native-multidim-fixtures' / source) as original:
        source_chunks = list(original['temperature'].chunks)
        assert np.array_equal(original['temperature'][:], data[:])
    object_hashes = {str(p.relative_to(store)): hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(store.rglob('*')) if p.is_file()}
    results.append({'source': source, 'store': store_name, 'shape': list(data.shape),
                    'dtype': str(data.dtype), 'source_chunks': source_chunks, 'output_chunks': list(data.chunks),
                    'rechunked': source_chunks != list(data.chunks), 'raw_value_mismatches': 0,
                    'masked_fill_cells': 2, 'coordinate_mismatches': 0, 'cf_mismatches': 0,
                    'output_object_sha256': object_hashes})
print(json.dumps({'scope': 'Canonical Zarr/xarray HTTP reads with consolidated metadata of actual bound diagnostic worker output through S3 emulator; full array, no subset efficiency or production qualification',
                  'versions': {'zarr': zarr.__version__, 'xarray': xr.__version__, 'numpy': np.__version__},
                  'results': results}, indent=2))
